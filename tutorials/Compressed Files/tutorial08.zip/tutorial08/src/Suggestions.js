import React from 'react';

export default function Suggestions() {
    // some logic here:


    // return some JSX
    return (
        <div className="suggestions">
            <div>
                Suggestions go here...
            </div>
        </div>
    )
}