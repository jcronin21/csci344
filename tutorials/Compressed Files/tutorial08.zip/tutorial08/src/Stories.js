import React from 'react';

export default function Stories() {
    // logic here


    // return some JSX
    return (
        <header className="stories">
            Stories go here...
        </header>
    )
}